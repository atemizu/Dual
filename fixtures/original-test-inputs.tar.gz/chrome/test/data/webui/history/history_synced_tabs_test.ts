// Copyright 2016 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import type {ForeignSession, HistorySyncedDeviceCardElement, HistorySyncedDeviceManagerElement} from 'chrome://history/history.js';
import {BrowserProxyImpl, foreignSessionBrowserProxyFactory, HistorySignInState, SyncState} from 'chrome://history/history.js';
import {webUIListenerCallback} from 'chrome://resources/js/cr.js';
import {loadTimeData} from 'chrome://resources/js/load_time_data.js';
import {assertEquals, assertFalse, assertNotEquals, assertTrue} from 'chrome://webui-test/chai_assert.js';
import {microtasksFinished} from 'chrome://webui-test/test_util.js';

// <if expr="not is_chromeos">
import {isChildVisible} from 'chrome://webui-test/test_util.js';
// </if>

import {FakeForeignSessionPageHandler} from './fake_foreign_session_page_handler.js';
import {TestHistoryBrowserProxy} from './test_browser_proxy.js';
import {createSession, createWindow} from './test_util.js';

function getCards(manager: HistorySyncedDeviceManagerElement):
    NodeListOf<HistorySyncedDeviceCardElement> {
  return manager.shadowRoot.querySelectorAll('history-synced-device-card');
}

function numWindowSeparators(card: HistorySyncedDeviceCardElement): number {
  return card.shadowRoot.querySelectorAll(':not([hidden]).window-separator')
      .length;
}

function assertNoSyncedTabsMessageShown(
    manager: HistorySyncedDeviceManagerElement, stringID: string) {
  assertFalse(manager.$.noSyncedTabs.hidden);
  const message = loadTimeData.getString(stringID);
  assertNotEquals(-1, manager.$.noSyncedTabs.textContent.indexOf(message));
}

suite('<history-synced-device-manager>', function() {
  let element: HistorySyncedDeviceManagerElement;
  let testProxy: TestHistoryBrowserProxy;
  let foreignSessionProxy: FakeForeignSessionPageHandler;

  function setForeignSessions(sessions: ForeignSession[]) {
    element.sessionList = sessions;
  }

  setup(function() {
    document.body.innerHTML = window.trustedTypes!.emptyHTML;
    window.history.replaceState({}, '', '/');
    testProxy = new TestHistoryBrowserProxy();
    BrowserProxyImpl.setInstance(testProxy);
    foreignSessionProxy = new FakeForeignSessionPageHandler();
    const {instance} =
        foreignSessionBrowserProxyFactory.createForTest(foreignSessionProxy);
    foreignSessionBrowserProxyFactory.setInstance(instance);
    testProxy.setInitialIdentityState({
      signIn: HistorySignInState.SIGNED_IN,
      tabsSync: SyncState.TURNED_ON,
      historySync: SyncState.TURNED_OFF,
    });
    element = document.createElement('history-synced-device-manager');
    // |signInState| is generally set after |searchTerm| in Polymer 2. Set in
    // the same order in tests, in order to catch regressions like
    // https://crbug.com/40606784.
    element.searchTerm = '';
    element.configureSignInForTest({
      signInAllowed: true,
      guestSession: false,
    });
    document.body.appendChild(element);
    return microtasksFinished();
  });

  test('single card, single window', async () => {
    const sessionList: ForeignSession[] = [createSession(
        'Nexus 5',
        [createWindow(['http://www.google.com', 'http://example.com'])])];
    setForeignSessions(sessionList);
    await microtasksFinished();

    const card =
        element.shadowRoot.querySelector('history-synced-device-card')!;
    assertEquals(
        'http://www.google.com',
        card.shadowRoot.querySelectorAll<HTMLElement>(
                           '.website-title')[0]!.textContent.trim());
    assertEquals(2, card.tabs.length);
  });

  test('two cards, multiple windows', async () => {
    const sessionList: ForeignSession[] = [
      createSession(
          'Nexus 5',
          [createWindow(['http://www.google.com', 'http://example.com'])]),
      createSession(
          'Nexus 6',
          [
            createWindow(['http://test.com']),
            createWindow(['http://www.gmail.com', 'http://badssl.com']),
          ]),
    ];
    setForeignSessions(sessionList);
    await microtasksFinished();

    const cards = getCards(element);
    assertEquals(2, cards.length);

    // Ensure separators between windows are added appropriately.
    assertEquals(0, numWindowSeparators(cards[0]!));
    assertEquals(1, numWindowSeparators(cards[1]!));
  });

  test('updating sessions', async () => {
    const session1 = createSession(
        'Chromebook',
        [createWindow(['http://www.example.com', 'http://crbug.com'])]);
    session1.timestamp = 1000;

    const session2 =
        createSession('Nexus 5', [createWindow(['http://www.google.com'])]);

    setForeignSessions([session1, session2]);
    await microtasksFinished();
    const session1updated = createSession('Chromebook', [
      createWindow(['http://www.example.com', 'http://crbug.com/new']),
      createWindow(['http://web.site']),
    ]);
    session1updated.timestamp = 1234;

    setForeignSessions([session1updated, session2]);
    await microtasksFinished();
    // There should only be two cards.
    const cards = getCards(element);
    assertEquals(2, cards.length);

    // There are now 2 windows in the first device.
    assertEquals(1, numWindowSeparators(cards[0]!));
    // Check that the actual link changes.
    assertEquals(
        'http://crbug.com/new',
        cards[0]!.shadowRoot.querySelectorAll<HTMLElement>(
                                '.website-title')[1]!.textContent.trim());
  });

  test('two cards, multiple windows, search', async () => {
    const sessionList: ForeignSession[] = [
      createSession(
          'Nexus 5',
          [createWindow(['http://www.google.com', 'http://example.com'])]),
      createSession(
          'Nexus 6',
          [
            createWindow(['http://www.gmail.com', 'http://badssl.com']),
            createWindow(['http://test.com']),
            createWindow(['http://www.gmail.com', 'http://bagssl.com']),
          ]),
    ];
    setForeignSessions(sessionList);
    await microtasksFinished();

    let cards = getCards(element);
    assertEquals(2, cards.length);

    // Ensure separators between windows are added appropriately.
    assertEquals(0, numWindowSeparators(cards[0]!));
    assertEquals(2, numWindowSeparators(cards[1]!));
    element.searchTerm = 'g';
    await microtasksFinished();

    cards = getCards(element);
    assertEquals(0, numWindowSeparators(cards[0]!));
    assertEquals(1, cards[0]!.tabs.length);
    assertEquals('http://www.google.com', cards[0]!.tabs[0]!.title);
    assertEquals(1, numWindowSeparators(cards[1]!));
    assertEquals(3, cards[1]!.tabs.length);
    assertEquals('http://www.gmail.com', cards[1]!.tabs[0]!.title);
    assertEquals('http://www.gmail.com', cards[1]!.tabs[1]!.title);
    assertEquals('http://bagssl.com', cards[1]!.tabs[2]!.title);

    // Ensure the title text is rendered during searches.
    assertEquals(
        'http://www.google.com',
        cards[0]!.shadowRoot.querySelectorAll<HTMLElement>(
                                '.website-title')[0]!.textContent.trim());

    element.searchTerm = 'Sans';
    await microtasksFinished();

    assertEquals(0, getCards(element).length);
    assertNoSyncedTabsMessageShown(element, 'noSearchResults');
  });

  test('delete a session', async () => {
    const sessionList: ForeignSession[] = [
      createSession('Nexus 5', [createWindow(['http://www.example.com'])]),
      createSession('Pixel C', [createWindow(['http://www.badssl.com'])]),
    ];

    setForeignSessions(sessionList);
    await microtasksFinished();

    let cards = getCards(element);
    assertEquals(2, cards.length);
    cards[0]!.$.menuButton.click();
    await microtasksFinished();

    element.shadowRoot.querySelector<HTMLElement>('#menuDeleteButton')!.click();
    const deletedSessionTag =
        await foreignSessionProxy.whenCalled('deleteForeignSession');
    assertEquals('Nexus 5', deletedSessionTag);

    // Simulate deleting the first device.
    setForeignSessions([sessionList[1]!]);
    await microtasksFinished();
    cards = getCards(element);
    assertEquals(1, cards.length);
    assertEquals('http://www.badssl.com', cards[0]!.tabs[0]!.title);
  });

  test('delete a collapsed session', async () => {
    const sessionList: ForeignSession[] = [
      createSession('Nexus 5', [createWindow(['http://www.example.com'])]),
      createSession('Pixel C', [createWindow(['http://www.badssl.com'])]),
    ];

    setForeignSessions(sessionList);
    await microtasksFinished();

    let cards = getCards(element);
    cards[0]!.$.cardHeading.click();
    await microtasksFinished();
    assertFalse(cards[0]!.opened);

    // Simulate deleting the first device.
    setForeignSessions([sessionList[1]!]);
    await microtasksFinished();
    cards = getCards(element);
    assertTrue(cards[0]!.opened);
  });

  test('click synced tab', async () => {
    setForeignSessions(
        [createSession('Chromebook', [createWindow(['https://example.com'])])]);
    await microtasksFinished();
    const cards = getCards(element);
    const anchor = cards[0]!.shadowRoot.querySelector('a')!;
    anchor.click();
    const [sessionTag, tabId, modifiers] =
        await foreignSessionProxy.whenCalled('openForeignSessionTab');
    assertEquals('Chromebook', sessionTag, 'sessionTag is correct');
    assertEquals(456, tabId, 'tabId is correct');
    assertFalse(modifiers.altKey, 'altKey is defined');
    assertFalse(modifiers.ctrlKey, 'ctrlKey is defined');
    assertFalse(modifiers.metaKey, 'metaKey is defined');
    assertFalse(modifiers.shiftKey, 'shiftKey is defined');
  });

  test('middle-click synced tab', async () => {
    setForeignSessions(
        [createSession('Chromebook', [createWindow(['https://example.com'])])]);
    await microtasksFinished();
    const cards = getCards(element);
    const anchor = cards[0]!.shadowRoot.querySelector('a')!;

    // Dispatch auxclick with button 1 (middle click).
    anchor.dispatchEvent(new MouseEvent('auxclick', {
      button: 1,
      cancelable: true,
      bubbles: true,
      composed: true,
    }));

    const [sessionTag, tabId, modifiers] =
        await foreignSessionProxy.whenCalled('openForeignSessionTab');
    assertEquals('Chromebook', sessionTag, 'sessionTag is correct');
    assertEquals(456, tabId, 'tabId is correct');
    assertTrue(modifiers.middleButton, 'middleButton is true');
  });

  test('show actions menu', async () => {
    setForeignSessions(
        [createSession('Chromebook', [createWindow(['https://example.com'])])]);
    await microtasksFinished();
    const cards = getCards(element);
    cards[0]!.$.menuButton.click();
    assertTrue(element.$.menu.getIfExists()!.open);
  });

  // <if expr="is_chromeos">
  // On ChromeOS, this promo may be shown depending on the
  // kReplaceSyncPromosWithSignInPromos flag value. For other platforms, the
  // flag is true so this promo is not shown (checked in other tests below).
  test('show sign in promo', async () => {
    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGNED_OUT,
      tabsSync: SyncState.TURNED_OFF,
      historySync: SyncState.TURNED_OFF,
    });
    await microtasksFinished();
    assertEquals(
        loadTimeData.getBoolean('replaceSyncPromosWithSignInPromos'),
        element.$.signInGuide.hidden);
    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGNED_IN,
      tabsSync: SyncState.TURNED_ON,
      historySync: SyncState.TURNED_OFF,
    });
    await microtasksFinished();
    assertTrue(element.$.signInGuide.hidden);
  });
  // </if>

  test('no synced tabs message', async () => {
    await microtasksFinished();
    // When user is not logged in, there is no synced tabs.
    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGNED_OUT,
      tabsSync: SyncState.TURNED_OFF,
      historySync: SyncState.TURNED_OFF,
    });
    element.clearSyncedDevicesForTest();
    await microtasksFinished();
    assertTrue(element.$.noSyncedTabs.hidden);

    let cards = getCards(element);
    assertEquals(0, cards.length);

    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGNED_IN,
      tabsSync: SyncState.TURNED_ON,
      historySync: SyncState.TURNED_OFF,
    });

    await microtasksFinished();
    // When user signs in, first show loading message.
    assertNoSyncedTabsMessageShown(element, 'loading');

    setForeignSessions([]);
    await microtasksFinished();
    cards = getCards(element);
    assertEquals(0, cards.length);
    // If no synced tabs are fetched, show 'no synced tabs'.
    assertNoSyncedTabsMessageShown(element, 'noSyncedResults');

    setForeignSessions([createSession(
        'Nexus 5',
        [createWindow(['http://www.google.com', 'http://example.com'])])]);

    await microtasksFinished();
    cards = getCards(element);
    assertEquals(1, cards.length);
    // If there are any synced tabs, hide the 'no synced tabs' message.
    assertTrue(element.$.noSyncedTabs.hidden);

    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGNED_OUT,
      tabsSync: SyncState.TURNED_OFF,
      historySync: SyncState.TURNED_OFF,
    });
    await microtasksFinished();
    // When user signs out, don't show the message.
    assertTrue(element.$.noSyncedTabs.hidden);
  });

  test('hide sign in promo in guest mode', async () => {
    element.configureSignInForTest({
      signInAllowed: true,
      guestSession: true,
    });
    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGNED_OUT,
      tabsSync: SyncState.TURNED_OFF,
      historySync: SyncState.TURNED_OFF,
    });
    await microtasksFinished();
    assertTrue(element.$.signInGuide.hidden);
  });

  test('hide sign-in promo if sign-in is disabled', async function() {
    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGNED_OUT,
      tabsSync: SyncState.TURNED_OFF,
      historySync: SyncState.TURNED_OFF,
    });
    element.configureSignInForTest({
      signInAllowed: false,
      guestSession: false,
    });
    await microtasksFinished();
    assertTrue(element.$.signInGuide.hidden);
  });

  test('no synced tabs message displays on load', async () => {
    // On initial load, the identityStateChanged_ callback is triggered, which
    // sets fetchingSyncedTabs_ to true and shows the 'loading' message. To test
    // the 'no synced results' message, we must simulate the completion of this
    // fetch operation with an empty session list.
    await microtasksFinished();
    setForeignSessions([]);
    element.clearSyncedDevicesForTest();
    // Should show no synced tabs message on initial load. Regression test for
    // https://crbug.com/40606784.
    await microtasksFinished();
    assertNoSyncedTabsMessageShown(element, 'noSyncedResults');
    const cards = getCards(element);
    assertEquals(0, cards.length);
  });
});

// <if expr="not is_chromeos">
// history-sync-optin elements is not shown for ChromeOS.
suite('<history-sync-optin>', function() {
  let element: HistorySyncedDeviceManagerElement;
  let testProxy: TestHistoryBrowserProxy;
  let foreignSessionProxy: FakeForeignSessionPageHandler;

  setup(function() {
    document.body.innerHTML = window.trustedTypes!.emptyHTML;
    window.history.replaceState({}, '', '/');
    testProxy = new TestHistoryBrowserProxy();
    BrowserProxyImpl.setInstance(testProxy);
    foreignSessionProxy = new FakeForeignSessionPageHandler();
    const {instance} =
        foreignSessionBrowserProxyFactory.createForTest(foreignSessionProxy);
    foreignSessionBrowserProxyFactory.setInstance(instance);
    testProxy.setInitialIdentityState({
      signIn: HistorySignInState.WEB_ONLY_SIGNED_IN,
      tabsSync: SyncState.TURNED_OFF,
      historySync: SyncState.TURNED_OFF,
    });

    // history-sync-optin elements are only shown when the
    // replaceSyncPromosWithSignInPromos is true
    loadTimeData.overrideValues({
      replaceSyncPromosWithSignInPromos: true,
    });

    element = document.createElement('history-synced-device-manager');
    // |signInState| is generally set after |searchTerm| in Polymer 2. Set in
    // the same order in tests, in order to catch regressions like
    // https://crbug.com/40606784.
    element.searchTerm = '';
    // Setting the sign in state to WEB_ONLY_SIGNED_IN, because user's name,
    // email and profile icon are only shown on the page when the sign in
    // state is WEB_ONLY_SIGNED_IN.
    element.configureSignInForTest({
      signInAllowed: true,
      guestSession: false,
    });
    document.body.appendChild(element);
    return microtasksFinished();
  });

  test('check history sync optin elements are visible', async () => {
    await microtasksFinished();

    // The old promo should not be visible.
    assertFalse(isChildVisible(element, '#turn-on-sync-promo'));

    // The new promo elements for WEB_ONLY_SIGNED_IN state are shown correctly.
    assertTrue(isChildVisible(element, '#sync-history-button'));
    assertTrue(isChildVisible(element, '#history-sync-optin'));
    assertTrue(isChildVisible(element, '#account-name'));
    assertTrue(isChildVisible(element, '#account-email'));
    assertTrue(isChildVisible(element, '#profile-icon'));
  });

  test('check elements in signed out state', async () => {
    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGNED_OUT,
      tabsSync: SyncState.TURNED_OFF,
      historySync: SyncState.TURNED_OFF,
    });
    await microtasksFinished();
    // Should not be visible with kReplaceSyncPromosWithSignInPromos enabled.
    assertFalse(isChildVisible(element, '#signInGuide'));
    // The other states promo elements should not be visible.
    assertFalse(isChildVisible(element, '#signed-in-sync-history-promo-desc'));
    assertFalse(isChildVisible(element, '#verify-its-you-button'));
    assertFalse(isChildVisible(
        element, '#sign-in-pending-sync-history-promo-desc-sync-history-on'));
    assertFalse(isChildVisible(element, '#sign-in-pending-avatar'));

    // The history sync promo elements for SIGNED_OUT state are shown correctly.
    assertTrue(isChildVisible(element, '#sync-history-button'));
    assertTrue(isChildVisible(element, '#signed-out-sync-history-promo-desc'));
  });

  test('check elements in pending signin without tabs sync state', async () => {
    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGN_IN_PENDING,
      tabsSync: SyncState.TURNED_OFF,
      historySync: SyncState.TURNED_OFF,
    });
    await microtasksFinished();

    // The other states promo elements should not be visible.
    assertFalse(isChildVisible(element, '#signed-out-sync-history-promo-desc'));
    assertFalse(isChildVisible(element, '#signed-in-sync-history-promo-desc'));
    assertFalse(isChildVisible(element, '#verify-its-you-button'));
    assertFalse(isChildVisible(
        element, '#sign-in-pending-sync-history-promo-desc-sync-history-on'));

    // The promo elements for SIGN_IN_PENDING_NOT_SYNCING_TABS state are
    // shown correctly.
    assertTrue(isChildVisible(element, '#sign-in-pending-avatar'));
    assertTrue(
        isChildVisible(element, '#sign-in-pending-sync-history-promo-desc'));
    assertTrue(isChildVisible(element, '#sync-history-button'));
  });

  test('check elements in pending signin with tabs sync state', async () => {
    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGN_IN_PENDING,
      tabsSync: SyncState.TURNED_ON,
      historySync: SyncState.TURNED_OFF,
    });
    await microtasksFinished();

    // The other states promo elements should not be visible.
    assertFalse(isChildVisible(element, '#sync-history-button'));
    assertFalse(
        isChildVisible(element, '#sign-in-pending-sync-history-promo-desc'));

    // The promo elements for SIGN_IN_PENDING_SYNCING_TABS state are
    // shown correctly.
    assertTrue(isChildVisible(element, '#sign-in-pending-avatar'));
    assertTrue(isChildVisible(
        element, '#sign-in-pending-sync-history-promo-desc-sync-history-on'));
    assertTrue(isChildVisible(element, '#verify-its-you-button'));
  });

  test('check elements in SYNC_DISABLED sign in state', async () => {
    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGNED_IN,
      tabsSync: SyncState.DISABLED,
      historySync: SyncState.TURNED_OFF,
    });
    await microtasksFinished();

    // The 'no synced tabs' message should be shown.
    assertTrue(isChildVisible(element, '#noSyncedTabs'));

    // The promo elements are not shown
    assertFalse(isChildVisible(element, '#history-sync-optin'));
    assertFalse(isChildVisible(element, '#sync-history-button'));
    assertFalse(isChildVisible(element, '#verify-its-you-button'));
  });

  test('initializes account info', async () => {
    await testProxy.handler.whenCalled('requestAccountInfo');
    await microtasksFinished();

    assertEquals(
        'Test User',
        element.shadowRoot.querySelector<HTMLElement>(
                              '#account-name')!.textContent.trim());
    assertEquals(
        'test@google.com',
        element.shadowRoot.querySelector<HTMLElement>(
                              '#account-email')!.textContent.trim());
    assertEquals(
        'http://example.com/image.png',
        element.shadowRoot.querySelector<HTMLImageElement>(
                              '#profile-icon')!.src);
  });

  test('updates account info', async () => {
    await testProxy.handler.whenCalled('requestAccountInfo');
    await microtasksFinished();

    const newAccountInfo = {
      name: 'Test User 2',
      email: 'test2@google.com',
      accountImageSrc: 'http://image.com/img2.png',
    };

    testProxy.pageRemote.sendAccountInfo(newAccountInfo);
    await microtasksFinished();

    assertEquals(
        newAccountInfo.name,
        element.shadowRoot.querySelector<HTMLElement>(
                              '#account-name')!.textContent.trim());
    assertEquals(
        newAccountInfo.email,
        element.shadowRoot.querySelector<HTMLElement>(
                              '#account-email')!.textContent.trim());
    assertEquals(
        newAccountInfo.accountImageSrc,
        element.shadowRoot.querySelector<HTMLImageElement>(
                              '#profile-icon')!.src);
  });

  test('calls turnOnHistorySync when button is clicked', async () => {
    // For the sake of diversity, using other signin state in this test,
    // different from WEB_ONLY_SIGN_IN
    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGNED_IN,
      tabsSync: SyncState.TURNED_OFF,
      historySync: SyncState.TURNED_OFF,
    });
    const button =
        element.shadowRoot.querySelector<HTMLElement>('#sync-history-button');
    assertTrue(!!button);
    button.click();

    await testProxy.handler.whenCalled('turnOnHistorySync');
  });

  test('check recorded metrics in pending signin', async () => {
    // The signin pending offered histogram is recorded once.
    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGN_IN_PENDING,
      tabsSync: SyncState.TURNED_OFF,
      historySync: SyncState.TURNED_OFF,
    });
    await microtasksFinished();
    assertEquals(1, testProxy.getCallCount('recordSigninPendingOffered'));

    // Firing a sign in pending state again does not record again.
    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGN_IN_PENDING,
      tabsSync: SyncState.TURNED_ON,
      historySync: SyncState.TURNED_OFF,
    });
    await microtasksFinished();
    assertEquals(1, testProxy.getCallCount('recordSigninPendingOffered'));

    // Signing in and then getting into sign in pending state again records the
    // histogram again.
    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGNED_IN,
      tabsSync: SyncState.TURNED_ON,
      historySync: SyncState.TURNED_OFF,
    });
    await microtasksFinished();
    webUIListenerCallback('history-identity-state-changed', {
      signIn: HistorySignInState.SIGN_IN_PENDING,
      tabsSync: SyncState.TURNED_ON,
      historySync: SyncState.TURNED_OFF,
    });
    await microtasksFinished();

    assertEquals(2, testProxy.getCallCount('recordSigninPendingOffered'));
  });
});
// </if>
