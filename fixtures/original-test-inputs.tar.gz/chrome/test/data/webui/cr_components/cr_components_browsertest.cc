// Copyright 2023 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "chrome/common/webui_url_constants.h"
#include "chrome/test/base/web_ui_mocha_browser_test.h"
#include "components/contextual_tasks/public/features.h"
#include "components/lens/lens_features.h"
#include "content/public/test/browser_test.h"
#include "content/public/test/file_system_chooser_test_helpers.h"
#include "ui/shell_dialogs/select_file_dialog.h"

#if !BUILDFLAG(IS_ANDROID)
#include "chrome/browser/browser_features.h"
#include "components/history_clusters/core/features.h"
#include "components/history_embeddings/core/history_embeddings_features.h"
#endif

typedef WebUIMochaBrowserTest CrComponentsTest;

IN_PROC_BROWSER_TEST_F(CrComponentsTest, ColorChangeListener) {
  set_test_loader_host(chrome::kChromeUIExtensionsHost);
  RunTest("cr_components/color_change_listener_test.js", "mocha.run()");
}

#if !BUILDFLAG(IS_ANDROID)
IN_PROC_BROWSER_TEST_F(CrComponentsTest, CustomizeColorSchemeMode) {
  set_test_loader_host(chrome::kChromeUICustomizeChromeSidePanelHost);
  RunTest("cr_components/customize_color_scheme_mode_test.js", "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsTest, HelpBubbleMixin) {
  set_test_loader_host(chrome::kChromeUINewTabPageHost);
  RunTest("cr_components/help_bubble/help_bubble_mixin_test.js", "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsTest, HelpBubble) {
  set_test_loader_host(chrome::kChromeUINewTabPageHost);
  RunTest("cr_components/help_bubble/help_bubble_test.js", "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsTest, HorizontalCarousel) {
  RunTest("cr_components/history_clusters/horizontal_carousel_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsTest, AudioLevelsProcessorTest) {
  RunTest("cr_components/composebox/composebox_audio_levels_test.js",
          "mocha.run()");
}

class CrComponentsHistoryEmbeddingsTest : public WebUIMochaBrowserTest {
 protected:
  CrComponentsHistoryEmbeddingsTest() {
    scoped_feature_list_.InitAndEnableFeature(
        history_embeddings::kHistoryEmbeddings);
    set_test_loader_host(chrome::kChromeUIHistoryHost);
  }

 private:
  base::test::ScopedFeatureList scoped_feature_list_;
};

IN_PROC_BROWSER_TEST_F(CrComponentsHistoryEmbeddingsTest, HistoryEmbeddings) {
  RunTest("cr_components/history_embeddings/history_embeddings_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsHistoryEmbeddingsTest,
                       HistoryEmbeddingsFilterChips) {
  RunTest("cr_components/history_embeddings/filter_chips_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsHistoryEmbeddingsTest,
                       HistoryEmbeddingsResultImage) {
  RunTest("cr_components/history_embeddings/result_image_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsTest, ManagedDialog) {
  RunTest("cr_components/managed_dialog_test.js", "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsTest, ManagedFootnote) {
  // Loaded from chrome://settings because it needs access to chrome.send().
  set_test_loader_host(chrome::kChromeUISettingsHost);
  RunTest("cr_components/managed_footnote_test.js", "mocha.run()");
}
#endif  // !BUILDFLAG(IS_ANDROID)

IN_PROC_BROWSER_TEST_F(CrComponentsTest, LocalizedLink) {
  RunTest("cr_components/localized_link_test.js", "mocha.run()");
}

#if !BUILDFLAG(IS_ANDROID)
typedef WebUIMochaBrowserTest CrComponentsSearchboxTest;
IN_PROC_BROWSER_TEST_F(CrComponentsSearchboxTest, RealboxMatchTest) {
  set_test_loader_host(chrome::kChromeUINewTabPageHost);
  RunTest("cr_components/searchbox/searchbox_match_test.js", "mocha.run()");
}


IN_PROC_BROWSER_TEST_F(CrComponentsSearchboxTest, SearchboxInputTest) {
  set_test_loader_host(chrome::kChromeUINewTabPageHost);
  RunTest("cr_components/searchbox/searchbox_input_test.js", "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsSearchboxTest, RealboxPlaceholderTest) {
  set_test_loader_host(chrome::kChromeUINewTabPageHost);
  RunTest("cr_components/searchbox/placeholder_text_cycler_test.js",
          "runMochaSuite('PlaceholderTextCyclerTest');");
}


IN_PROC_BROWSER_TEST_F(CrComponentsSearchboxTest, SearchboxDropdownTest) {
  set_test_loader_host(chrome::kChromeUINewTabPageHost);
  RunTest("cr_components/searchbox/searchbox_dropdown_test.js", "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsSearchboxTest, SearchboxSelectionMixin) {
  RunTest("cr_components/searchbox/searchbox_selection_mixin_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsSearchboxTest, SearchboxIconTest) {
  set_test_loader_host(chrome::kChromeUINewTabPageHost);
  RunTest("cr_components/searchbox/searchbox_icon_test.js", "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsSearchboxTest, SearchboxMixinTest) {
  set_test_loader_host(chrome::kChromeUINewTabPageHost);
  RunTest("cr_components/searchbox/searchbox_mixin_test.js", "mocha.run()");
}

class CrComponentsHistoryClustersTest : public WebUIMochaBrowserTest {
 protected:
  CrComponentsHistoryClustersTest() {
    scoped_feature_list_.InitAndEnableFeature(
        history_clusters::internal::kJourneysImages);
    set_test_loader_host(chrome::kChromeUIHistoryHost);
  }

 private:
  base::test::ScopedFeatureList scoped_feature_list_;
};

// TODO(crbug.com/390550686): Test is flaky.
#if BUILDFLAG(IS_LINUX) || BUILDFLAG(IS_MAC) || BUILDFLAG(IS_CHROMEOS)
#define MAYBE_All DISABLED_All
#else
#define MAYBE_All All
#endif
IN_PROC_BROWSER_TEST_F(CrComponentsHistoryClustersTest, MAYBE_All) {
  RunTest("cr_components/history_clusters/history_clusters_test.js",
          "runMochaSuite('HistoryClustersTest')");
}

IN_PROC_BROWSER_TEST_F(CrComponentsHistoryClustersTest, Cluster) {
  RunTest("cr_components/history_clusters/cluster_test.js", "mocha.run()");
}

class CrComponentsMostVisitedTest : public WebUIMochaBrowserTest {
 protected:
  CrComponentsMostVisitedTest() {
    set_test_loader_host(chrome::kChromeUINewTabPageHost);
  }
};

IN_PROC_BROWSER_TEST_F(CrComponentsMostVisitedTest, General) {
  RunTest("cr_components/most_visited_test.js", "runMochaSuite('General');");
}

// TODO(https://crbug.com/449760234): Times out on linux debug builds.
#if BUILDFLAG(IS_LINUX) && !defined(NDEBUG)
#define MAYBE_Layouts DISABLED_Layouts
#else
#define MAYBE_Layouts Layouts
#endif
IN_PROC_BROWSER_TEST_F(CrComponentsMostVisitedTest, MAYBE_Layouts) {
  RunTest("cr_components/most_visited_test.js", "runMochaSuite('Layouts');");
}

IN_PROC_BROWSER_TEST_F(CrComponentsMostVisitedTest, ReflowLayouts) {
  RunTest("cr_components/most_visited_test.js",
          "runMochaSuite('Reflow Layouts');");
}

IN_PROC_BROWSER_TEST_F(CrComponentsMostVisitedTest, LoggingAndUpdates) {
  RunTest("cr_components/most_visited_test.js",
          "runMochaSuite('LoggingAndUpdates');");
}

// crbug.com/40776780
#if BUILDFLAG(IS_LINUX) && !defined(NDEBUG)
#define MAYBE_Modification DISABLED_Modification
#else
#define MAYBE_Modification Modification
#endif
IN_PROC_BROWSER_TEST_F(CrComponentsMostVisitedTest, MAYBE_Modification) {
  RunTest("cr_components/most_visited_test.js",
          "runMochaSuite('Modification');");
}

IN_PROC_BROWSER_TEST_F(CrComponentsMostVisitedTest, DragAndDrop) {
  RunTest("cr_components/most_visited_test.js",
          "runMochaSuite('DragAndDrop');");
}

IN_PROC_BROWSER_TEST_F(CrComponentsMostVisitedTest, EnterpriseShortcuts) {
  RunTest("cr_components/most_visited_test.js",
          "runMochaSuite('EnterpriseShortcuts');");
}

IN_PROC_BROWSER_TEST_F(CrComponentsMostVisitedTest, Theming) {
  RunTest("cr_components/most_visited_test.js", "runMochaSuite('Theming');");
}

IN_PROC_BROWSER_TEST_F(CrComponentsMostVisitedTest, ShowAddButton) {
  RunTest("cr_components/most_visited_test.js",
          "runMochaSuite('ShowAddButton');");
}

IN_PROC_BROWSER_TEST_F(CrComponentsMostVisitedTest, ExpandableTiles) {
  RunTest("cr_components/most_visited_test.js",
          "runMochaSuite('ExpandableTiles');");
}

IN_PROC_BROWSER_TEST_F(CrComponentsMostVisitedTest, ShortcutsAutoRemovalToast) {
  RunTest("cr_components/most_visited_test.js",
          "runMochaSuite('ShortcutsAutoRemovalToast');");
}

typedef WebUIMochaBrowserTest CrComponentsThemeColorPickerTest;
IN_PROC_BROWSER_TEST_F(CrComponentsThemeColorPickerTest, ThemeColor) {
  set_test_loader_host(chrome::kChromeUICustomizeChromeSidePanelHost);
  RunTest("cr_components/theme_color_picker/theme_color_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsThemeColorPickerTest, CheckMarkWrapper) {
  set_test_loader_host(chrome::kChromeUICustomizeChromeSidePanelHost);
  RunTest("cr_components/theme_color_picker/check_mark_wrapper_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsThemeColorPickerTest, ThemeColorPicker) {
  set_test_loader_host(chrome::kChromeUICustomizeChromeSidePanelHost);
  RunTest("cr_components/theme_color_picker/theme_color_picker_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsThemeColorPickerTest, ThemeHueSliderDialog) {
  set_test_loader_host(chrome::kChromeUICustomizeChromeSidePanelHost);
  RunTest("cr_components/theme_color_picker/theme_hue_slider_dialog_test.js",
          "mocha.run()");
}

class CrComponentsPreloadingTest : public CrComponentsMostVisitedTest {
 protected:
  CrComponentsPreloadingTest() {
    scoped_feature_list_.InitWithFeaturesAndParameters(
        {base::test::FeatureRefAndParams(
             features::kNewTabPageTriggerForPrerender2,
             {{"preconnect_start_delay_on_mouse_hover_ms", "0"}}),
         base::test::FeatureRefAndParams(
             features::kNewTabPageTriggerForPrefetch,
             {{"prefetch_start_delay_on_mouse_hover_ms", "0"}})},
        {});
  }

 private:
  base::test::ScopedFeatureList scoped_feature_list_;
};

IN_PROC_BROWSER_TEST_F(CrComponentsPreloadingTest, Preloading) {
  RunTest("cr_components/most_visited_test.js", "runMochaSuite('Preloading');");
}
#endif  // !BUILDFLAG(IS_ANDROID)

class CrComponentsComposeboxTest : public WebUIMochaBrowserTest {
 protected:
  CrComponentsComposeboxTest() {
    scoped_feature_list_.InitWithFeatures(
        /*enabled_features=*/{contextual_tasks::kContextualTasks},
        /*disabled_features=*/{lens::features::kLensSendRawFileMediaTypes});

    set_test_loader_host(chrome::kChromeUIContextualTasksHost);
  }

 private:
  base::test::ScopedFeatureList scoped_feature_list_;
};

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, ContextualEntrypointButton) {
  RunTest("cr_components/composebox/contextual_entrypoint_button_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, ContextualEntrypointAndMenu) {
  RunTest("cr_components/composebox/contextual_entrypoint_and_menu_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, ComposeboxFaviconGroup) {
  RunTest("cr_components/composebox/composebox_favicon_group_test.js",
          "mocha.run()");
}

// TODO(crbug.com/513266451): Enable for Android.
#if !BUILDFLAG(IS_ANDROID)
IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, ContextualActionMenu) {
  RunTest("cr_components/composebox/contextual_action_menu_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest,
                       ComposeboxAudioWaveAnimation) {
  RunTest("cr_components/composebox/composebox_audio_animation_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, RecordingWave) {
  RunTest("cr_components/composebox/recording_wave_test.js", "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, LensSearch) {
  RunTest("cr_components/composebox/composebox_lens_search_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, CurrentTabChip) {
  RunTest("cr_components/composebox/current_tab_chip_test.js", "mocha.run()");
}
#endif

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, ComposeboxVoiceSearch) {
  RunTest("cr_components/composebox/composebox_voice_search_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest,
                       ComposeboxVoiceSearchMetrics) {
  RunTest("cr_components/composebox/composebox_voice_search_metrics_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest,
                       ComposeboxVoiceSearchRecognition) {
  RunTest(
      "cr_components/composebox/composebox_voice_search_recognition_test.js",
      "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, ComposeboxVoiceSearchFlags) {
  RunTest("cr_components/composebox/composebox_voice_search_flags_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, ComposeboxDragAndDrop) {
  RunTest("cr_components/composebox/composebox_drag_drop_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, ComposeboxErrorScrim) {
  RunTest("cr_components/composebox/error_scrim_test.js", "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, ComposeboxFileCarousel) {
  RunTest("cr_components/composebox/file_carousel_test.js", "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, ComposeboxFileThumbnail) {
  RunTest("cr_components/composebox/file_thumbnail_test.js", "mocha.run()");
}

class CrComponentsComposeboxFileInputsTest : public CrComponentsComposeboxTest {
 public:
  void SetUpOnMainThread() override {
    CrComponentsComposeboxTest::SetUpOnMainThread();
    ui::SelectFileDialog::SetFactory(
        std::make_unique<content::FakeSelectFileDialogFactory>(
            std::vector<base::FilePath>{}));
  }

  void TearDownOnMainThread() override {
    ui::SelectFileDialog::SetFactory(nullptr);
    CrComponentsComposeboxTest::TearDownOnMainThread();
  }
};

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxFileInputsTest,
                       ComposeboxFileInputs) {
  RunTest("cr_components/composebox/composebox_file_inputs_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, ComposeboxInput) {
  RunTest("cr_components/composebox/composebox_input_test.js", "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, ComposeboxInputPlaceholder) {
  RunTest("cr_components/composebox/composebox_input_placeholder_test.js",
          "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, ComposeboxMatch) {
  RunTest("cr_components/composebox/composebox_match_test.js", "mocha.run()");
}

IN_PROC_BROWSER_TEST_F(CrComponentsComposeboxTest, ComposeboxMixin) {
  RunTest("cr_components/composebox/composebox_mixin_test.js", "mocha.run()");
}
