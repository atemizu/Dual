// Copyright 2025 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'chrome://contextual-tasks/strings.m.js';

import {ErrorScrimElement} from 'chrome://resources/cr_components/composebox/error_scrim.js';
import type {CrButtonElement} from 'chrome://resources/cr_elements/cr_button/cr_button.js';
import {assertEquals, assertFalse, assertTrue} from 'chrome://webui-test/chai_assert.js';
import {microtasksFinished} from 'chrome://webui-test/test_util.js';

suite('ComposeboxErrorScrimTest', () => {
  let errorScrimElement: ErrorScrimElement;

  setup(() => {
    document.body.innerHTML = window.trustedTypes!.emptyHTML;
    errorScrimElement = new ErrorScrimElement();
    document.body.appendChild(errorScrimElement);
  });

  test('Both the error scrim and dismiss button are visible', async () => {
    // Assert initial state.
    const initialScrim =
        errorScrimElement.shadowRoot.querySelector('#errorScrim');
    assertEquals(initialScrim, null);

    // Act.
    const emptyFileErrorMessage = 'Can\'t upload. File appears to be empty.';
    errorScrimElement.errorMessage = emptyFileErrorMessage;
    await microtasksFinished();

    // Assert.
    const errorScrim =
        errorScrimElement.shadowRoot.querySelector('#errorScrim');
    assertTrue(!!errorScrim);

    // Assert: error scrim should be displayed correctly.
    const errorMessageElement = errorScrim.querySelector('#errorMessage');
    assertTrue(!!errorMessageElement);
    assertEquals(errorMessageElement.textContent, emptyFileErrorMessage);

    // Assert: Dismiss button should be visible and available.
    const dismissButton =
        errorScrim.querySelector<CrButtonElement>('#dismissErrorButton');
    assertTrue(!!dismissButton);
    assertFalse(dismissButton.disabled);
  });

  test('Error scrim should fire dismiss error scrim event', async () => {
    // Initial act: display error scrim.
    const emptyFileErrorMessage = 'Can\'t upload. File appears to be empty.';

    errorScrimElement.errorMessage = emptyFileErrorMessage;
    await microtasksFinished();

    // Assert Initial state.
    const initialScrim =
        errorScrimElement.shadowRoot.querySelector('#errorScrim');
    assertTrue(!!initialScrim);

    // Act.
    let dismissEventFired = false;
    errorScrimElement.addEventListener(
        'dismiss-error-scrim', () => dismissEventFired = true);

    const dismissButton =
        initialScrim.querySelector<CrButtonElement>('#dismissErrorButton')!;
    dismissButton.click();
    await microtasksFinished();

    // Event should be fired.
    assertTrue(dismissEventFired);
  });
});
