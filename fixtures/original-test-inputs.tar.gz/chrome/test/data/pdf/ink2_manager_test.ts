// Copyright 2025 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import type {AnnotationBrush, TextAnnotation, TextAnnotationMessageData, TextAttributes, TextBoxInit, UndoRedoStateChangedDetail, Viewport} from 'chrome-extension://mhjfbmdgcfjbbpaeojofohoefgiehjai/pdf_viewer_wrapper.js';
import {AnnotationBrushType, DEFAULT_TEXTBOX_WIDTH, Ink2Manager, MIN_TEXTBOX_SIZE_PX, PluginController, PluginControllerEventType, TextAlignment, TextAnnotationSource, TextTypeface} from 'chrome-extension://mhjfbmdgcfjbbpaeojofohoefgiehjai/pdf_viewer_wrapper.js';
import {assert} from 'chrome://resources/js/assert.js';
import {eventToPromise} from 'chrome://webui-test/test_util.js';

import {assertAnnotationBrush, assertDeepEquals, getTestAnnotation, MockDocumentDimensions, setGetAnnotationBrushReply, setUpInkTestContext} from './test_util.js';
import type {MockPdfPluginElement} from './test_util.js';

let viewport: Viewport;
let mockPlugin: MockPdfPluginElement;

function setUpInk2Manager(): Ink2Manager {
  Ink2Manager.setInstance(null);
  const context = setUpInkTestContext();
  viewport = context.viewport;
  mockPlugin = context.mockPlugin;
  return Ink2Manager.getInstance();
}

async function setUpDrawMode(): Promise<Ink2Manager> {
  const manager = setUpInk2Manager();
  await manager.initializeBrush();
  return manager;
}

async function setUpTextMode(): Promise<Ink2Manager> {
  const manager = setUpInk2Manager();
  const textAttributes = getTestAnnotation(0).textAttributes;
  manager.setTextTypeface(textAttributes.typeface);
  manager.setTextSize(textAttributes.size);
  manager.setTextAlignment(textAttributes.alignment);
  manager.setTextColor(textAttributes.color);
  manager.setTextStyles(textAttributes.styles);
  await manager.initializeTextAnnotations();
  return manager;
}

// Calls initializeTextAnnotation() with `point` as the location if provided,
// and listens for and returns the resulting initialize-text-box event.
async function changeActiveAnnotation(
    manager: Ink2Manager,
    point: {x: number, y: number}|null): Promise<CustomEvent<TextBoxInit>> {
  const whenInitEvent =
      eventToPromise<CustomEvent<TextBoxInit>>('initialize-text-box', manager);

  const created = point ? await manager.initializeTextAnnotation(point) :
                          await manager.initializeTextAnnotation();
  chrome.test.assertTrue(created);

  return whenInitEvent;
}

function getTestAnnotationMessageData(id: number): TextAnnotationMessageData {
  return {
    ...getTestAnnotation(id),
    isEdited: false,
    newTypefaces: [],
    source: TextAnnotationSource.USER,
  };
}

// Verifies that the plugin received a editTextAnnotation message for annotation
// with id 0.
function verifyEditTextAnnotationMessage(expected: boolean, id: number = 0) {
  const editTextAnnotationMessage =
      mockPlugin.findMessage<{type: string, data: number}>(
          'editTextAnnotation');
  chrome.test.assertEq(expected, editTextAnnotationMessage !== undefined);
  if (expected) {
    chrome.test.assertEq('editTextAnnotation', editTextAnnotationMessage!.type);
    chrome.test.assertEq(id, editTextAnnotationMessage!.data);
  }
}

function verifyFinishTextAnnotationMessage(
    expectedMessage: TextAnnotationMessageData) {
  const finishTextAnnotationMessage =
      mockPlugin.findMessage<{type: string, data: TextAnnotationMessageData}>(
          'finishTextAnnotation');
  chrome.test.assertTrue(finishTextAnnotationMessage !== undefined);
  chrome.test.assertEq(
      'finishTextAnnotation', finishTextAnnotationMessage.type);
  assertDeepEquals(expectedMessage, finishTextAnnotationMessage.data);
}

// Simulates the way the viewport is rotated from the plugin by setting updated
// DocumentDimensions. Assumes a non-rotated pageWidth of 400 and pageHeight of
// 500.
function rotateViewport(orientation: number) {
  const rotatedDocumentDimensions = new MockDocumentDimensions(0, 0);
  // When the plugin notifies the viewport of new dimensions for a rotation,
  // it swaps the width and height if the page is oriented sideways.
  if (orientation === 0 || orientation === 2) {
    rotatedDocumentDimensions.addPage(400, 500);
  } else {
    rotatedDocumentDimensions.addPage(500, 400);
  }
  rotatedDocumentDimensions.layoutOptions = {
    defaultPageOrientation: orientation,  // 90 degree CCW rotation
    direction: 2,                         // LTR
    twoUpViewEnabled: false,
  };
  viewport.setDocumentDimensions(rotatedDocumentDimensions);
}

chrome.test.runTests([
  async function testInitializeBrush() {
    const manager = setUpInk2Manager();
    chrome.test.assertFalse(manager.isInitializationStarted());
    chrome.test.assertFalse(manager.isInitializationComplete());

    // Initialize the brush.
    const brushPromise = manager.initializeBrush();
    chrome.test.assertTrue(manager.isInitializationStarted());
    await brushPromise;
    chrome.test.assertTrue(manager.isInitializationComplete());

    // Check that the manager requested the current annotation brush.
    const getAnnotationBrushMessage =
        mockPlugin.findMessage<{type: string}>('getAnnotationBrush');
    chrome.test.assertTrue(getAnnotationBrushMessage !== undefined);
    chrome.test.assertEq('getAnnotationBrush', getAnnotationBrushMessage.type);

    // Check that the manager's brush is the one reported by the plugin.
    const brush = manager.getCurrentBrush();

    // Defaults set in `setupTestMockPluginForInk()`.
    chrome.test.assertEq(AnnotationBrushType.PEN, brush.type);
    assert(brush.color);
    chrome.test.assertEq(0, brush.color.r);
    chrome.test.assertEq(0, brush.color.g);
    chrome.test.assertEq(0, brush.color.b);
    chrome.test.assertEq(3, brush.size);

    chrome.test.succeed();
  },

  async function testSetBrushProperties() {
    const manager = await setUpDrawMode();
    const brushUpdates: AnnotationBrush[] = [];
    manager.addEventListener('brush-changed', e => {
      brushUpdates.push((e as CustomEvent<AnnotationBrush>).detail);
    });

    function assertBrushUpdate(index: number, expected: AnnotationBrush) {
      chrome.test.assertEq(index + 1, brushUpdates.length);
      chrome.test.assertEq(expected.type, brushUpdates[index]!.type);
      if (expected.color) {
        assertDeepEquals(expected.color, brushUpdates[index]!.color);
      }
      chrome.test.assertEq(expected.size, brushUpdates[index]!.size);
    }

    // Set "yellow 1" pen color and ensure the plugin is updated and the update
    // event is fired.
    const yellow1 = {r: 253, g: 214, b: 99};
    let expectedBrush = {
      type: AnnotationBrushType.PEN,
      color: yellow1,
      size: 3,
    };
    manager.setBrushColor(yellow1);
    assertAnnotationBrush(mockPlugin, expectedBrush);
    assertBrushUpdate(0, expectedBrush);

    // Set size to 1 and ensure the plugin is updated and the update event is
    // fired.
    manager.setBrushSize(1);
    expectedBrush.size = 1;
    assertAnnotationBrush(mockPlugin, expectedBrush);
    assertBrushUpdate(1, expectedBrush);

    // Set the highlighter and ensure plugin is updated and update event is
    // fired.
    const lightRed = {r: 242, g: 139, b: 130};
    expectedBrush = {
      type: AnnotationBrushType.HIGHLIGHTER,
      color: lightRed,
      size: 8,
    };
    setGetAnnotationBrushReply(
        mockPlugin, AnnotationBrushType.HIGHLIGHTER, /*size=*/ 8, lightRed);
    await manager.setBrushType(AnnotationBrushType.HIGHLIGHTER);
    // Should have set the highlighter brush with the parameters from the
    // mock plugin.
    assertAnnotationBrush(mockPlugin, expectedBrush);
    assertBrushUpdate(2, expectedBrush);

    chrome.test.succeed();
  },

  async function testInitializeText() {
    const manager = setUpInk2Manager();
    chrome.test.assertFalse(manager.isTextInitializationComplete());

    // Initialize text annotation mode.
    const whenUpdated = eventToPromise('annotations-updated', manager);
    const textPromise = manager.initializeTextAnnotations();
    await textPromise;
    chrome.test.assertTrue(manager.isTextInitializationComplete());
    await whenUpdated;

    // Check that the manager requested all the text annotations.
    const getAllTextAnnotationsMessage =
        mockPlugin.findMessage<{type: string}>('getAllTextAnnotations');
    chrome.test.assertTrue(getAllTextAnnotationsMessage !== undefined);
    chrome.test.assertEq(
        'getAllTextAnnotations', getAllTextAnnotationsMessage.type);

    chrome.test.succeed();
  },

  async function testInitializeTextNonEmpty() {
    const manager = setUpInk2Manager();

    // Set the reply to getAllTextAnnotations to return non-empty.
    const testAnnotation1 = getTestAnnotation(0);
    const testAnnotation2 = getTestAnnotation(1);
    testAnnotation2.text = 'Goodbye Moon';
    testAnnotation2.textBoxRect = {
      height: 25,
      locationX: 60,
      locationY: 65,
      width: 50,
    };
    testAnnotation2.textAttributes.color = {r: 100, g: 0, b: 0};
    testAnnotation2.textAttributes.size = 10;
    mockPlugin.clearMessages();
    mockPlugin.setMessageReply('getAllTextAnnotations', {
      annotations: [testAnnotation1, testAnnotation2],
    });

    chrome.test.assertFalse(manager.isTextInitializationComplete());
    const whenUpdated = eventToPromise('annotations-updated', manager);
    await manager.initializeTextAnnotations();
    chrome.test.assertTrue(manager.isTextInitializationComplete());
    await whenUpdated;

    // Check that the manager requested all the text annotations.
    const getAllTextAnnotationsMessage =
        mockPlugin.findMessage<{type: string}>('getAllTextAnnotations');
    chrome.test.assertTrue(getAllTextAnnotationsMessage !== undefined);
    chrome.test.assertEq(
        'getAllTextAnnotations', getAllTextAnnotationsMessage.type);

    chrome.test.succeed();
  },

  async function testReactivateAnnotation() {
    const manager = setUpInk2Manager();

    // Set the reply to getAllTextAnnotations to return non-empty.
    const testAnnotation = getTestAnnotation(0);
    testAnnotation.text = 'Hello World';
    testAnnotation.textAttributes.color = {r: 0, g: 100, b: 0};
    testAnnotation.textAttributes.size = 12;

    mockPlugin.clearMessages();
    mockPlugin.setMessageReply('getAllTextAnnotations', {
      annotations: [testAnnotation],
    });

    await manager.initializeTextAnnotations();

    // Reactivate the annotation.
    const whenUpdatedColor = eventToPromise<CustomEvent<TextAttributes>>(
        'attributes-changed', manager);
    manager.reactivateTextAnnotation(testAnnotation);

    // Verify that the backend was notified.
    verifyEditTextAnnotationMessage(true, testAnnotation.id);

    // Verify that the manager's active attributes were updated to match the
    // reactivated annotation.
    const updateEvent = await whenUpdatedColor;
    assertDeepEquals(testAnnotation.textAttributes, updateEvent.detail);
    assertDeepEquals(
        testAnnotation.textAttributes, manager.getCurrentTextAttributes());

    // Verify that committing it sends the correct message.
    mockPlugin.clearMessages();
    manager.commitTextAnnotation(testAnnotation, true, []);

    const finishTextAnnotationMessage =
        mockPlugin.findMessage<{type: string, data: TextAnnotationMessageData}>(
            'finishTextAnnotation');
    chrome.test.assertTrue(finishTextAnnotationMessage !== undefined);
    chrome.test.assertEq(
        'finishTextAnnotation', finishTextAnnotationMessage.type);
    const expectedMessageData: TextAnnotationMessageData = {
      ...testAnnotation,
      isEdited: true,
      mojoTextInfo: new ArrayBuffer(0),
      newTypefaces: [],
      source: TextAnnotationSource.USER,
    };
    assertDeepEquals(expectedMessageData, finishTextAnnotationMessage.data);

    chrome.test.succeed();
  },

  async function testInitializeTextSingleLoadedAnnotation() {
    const manager = setUpInk2Manager();

    // Set the reply to getAllTextAnnotations to return a single loaded
    // annotation with ID 0.
    const testAnnotation = getTestAnnotation(0);
    mockPlugin.clearMessages();
    mockPlugin.setMessageReply('getAllTextAnnotations', {
      annotations: [testAnnotation],
    });

    chrome.test.assertFalse(manager.isTextInitializationComplete());
    await manager.initializeTextAnnotations();
    chrome.test.assertTrue(manager.isTextInitializationComplete());

    // Check that initializing a new annotation gets ID 1 (not 0, to avoid
    // collision).
    mockPlugin.clearMessages();
    const whenInitEvent = eventToPromise<CustomEvent<TextBoxInit>>(
        'initialize-text-box', manager);
    const created = await manager.initializeTextAnnotation({x: 200, y: 200});
    chrome.test.assertTrue(created);
    const initEvent = await whenInitEvent;
    chrome.test.assertEq(1, initEvent.detail.annotation.id);
    verifyEditTextAnnotationMessage(false);

    mockPlugin.clearMessages();
    chrome.test.succeed();
  },

  function testSetFontProperties() {
    const manager = setUpInk2Manager();
    const fontUpdates: TextAttributes[] = [];
    manager.addEventListener('attributes-changed', e => {
      fontUpdates.push((e as CustomEvent<TextAttributes>).detail);
    });

    function assertTextUpdate(index: number, expected: TextAttributes) {
      chrome.test.assertEq(index + 1, fontUpdates.length);
      chrome.test.assertEq(expected.typeface, fontUpdates[index]!.typeface);
      chrome.test.assertEq(expected.size, fontUpdates[index]!.size);
      assertDeepEquals(expected.color, fontUpdates[index]!.color);
      chrome.test.assertEq(expected.alignment, fontUpdates[index]!.alignment);
      assertDeepEquals(expected.styles, fontUpdates[index]!.styles);
    }

    // Update font. Note the other `expectedAttributes` values come from the
    // defaults set in ink2_manager.ts.
    manager.setTextTypeface(TextTypeface.SERIF);
    const expectedAttributes = {
      typeface: TextTypeface.SERIF,
      size: 12,
      color: {r: 0, g: 0, b: 0},
      alignment: TextAlignment.LEFT,
      styles: {
        bold: false,
        italic: false,
      },
    };
    assertTextUpdate(0, expectedAttributes);

    // Set size to 10.
    manager.setTextSize(10);
    expectedAttributes.size = 10;
    assertTextUpdate(1, expectedAttributes);

    // Set alignment to CENTER.
    manager.setTextAlignment(TextAlignment.CENTER);
    expectedAttributes.alignment = TextAlignment.CENTER;
    assertTextUpdate(2, expectedAttributes);

    // Set color to blue.
    const blue = {r: 0, g: 0, b: 100};
    manager.setTextColor(blue);
    expectedAttributes.color = blue;
    assertTextUpdate(3, expectedAttributes);

    // Set style to bold + italic.
    const boldItalic = {bold: true, italic: true};
    manager.setTextStyles(boldItalic);
    expectedAttributes.styles = boldItalic;
    assertTextUpdate(4, expectedAttributes);

    chrome.test.succeed();
  },

  async function testNoInitializeOutsidePage() {
    const manager = await setUpTextMode();
    let initEvents = 0;
    manager.addEventListener('initialize-text-box', () => {
      initEvents++;
    });

    // x offset is (viewportWidth - documentWidth) / 2 + shadow = 55. A click
    // anywhere to the left of that should not initialize an annotation and
    // should return false.
    const created1 = await manager.initializeTextAnnotation({x: 40, y: 20});
    chrome.test.assertFalse(created1);
    chrome.test.assertEq(0, initEvents);

    // Similarly, there is 55px of margin on the right side where a click should
    // return false.
    const created2 = await manager.initializeTextAnnotation({x: 480, y: 400});
    chrome.test.assertFalse(created2);
    chrome.test.assertEq(0, initEvents);

    chrome.test.succeed();
  },

  async function testInitializeTextboxNoLocation() {
    const manager = await setUpTextMode();
    // Use the same values as testSetFontProperties, since this test was
    // originally written with those values accidentally leaking into this test.
    manager.setTextTypeface(TextTypeface.SERIF);
    manager.setTextSize(10);
    manager.setTextAlignment(TextAlignment.CENTER);
    const red = {r: 255, b: 0, g: 0};
    manager.setTextColor(red);
    const boldItalic = {bold: true, italic: true};
    manager.setTextStyles(boldItalic);

    const whenInitEvent = eventToPromise<CustomEvent<TextBoxInit>>(
        'initialize-text-box', manager);
    // Initialize without a location. This is what happens when the user creates
    // a textbox by using "Enter" on the plugin, instead of with the mouse.
    const created1 = await manager.initializeTextAnnotation();
    chrome.test.assertTrue(created1);
    let initEvent = await whenInitEvent;

    // The full document fits in the window.
    chrome.test.assertEq(
        MIN_TEXTBOX_SIZE_PX, initEvent.detail.annotation.textBoxRect.height);
    // The page is centered on the viewport in the x direction, so it runs from
    // 55 to 445 after subtracting the 5px shadows on each side. The center is
    // at (55 + 445) / 2 = 250. Subtract half the default width to get the left
    // edge.
    chrome.test.assertEq(
        250 - DEFAULT_TEXTBOX_WIDTH / 2,
        initEvent.detail.annotation.textBoxRect.locationX);
    // The visible page starts at the y shadow/margin, which is 3, and is 490
    // tall after accounting for shadows. The center is at
    // (493 + 3) / 2 = 248. Subtract half the default height to get the top
    // edge.
    chrome.test.assertEq(
        248 - MIN_TEXTBOX_SIZE_PX / 2,
        initEvent.detail.annotation.textBoxRect.locationY);
    chrome.test.assertEq(
        DEFAULT_TEXTBOX_WIDTH, initEvent.detail.annotation.textBoxRect.width);
    chrome.test.assertEq(0, initEvent.detail.annotation.pageIndex);
    chrome.test.assertEq(55, initEvent.detail.pageDimensions.x);
    chrome.test.assertEq(3, initEvent.detail.pageDimensions.y);
    chrome.test.assertEq(390, initEvent.detail.pageDimensions.width);
    chrome.test.assertEq(490, initEvent.detail.pageDimensions.height);

    // Zoom to 2.0. Now, the new annotation should be centered on the visible
    // portion of the page.
    viewport.setZoom(2.0);
    // Initialize without a location. This is what happens when the user creates
    // a textbox by using "Enter" on the plugin, instead of with the mouse.
    initEvent = await changeActiveAnnotation(manager, null);

    chrome.test.assertEq(
        MIN_TEXTBOX_SIZE_PX, initEvent.detail.annotation.textBoxRect.height);
    // The page starts at the x shadow/margin, which is 10, and goes to the
    // viewport edge. The center is (500 + 10) / 2 = 255. Subtract half the
    // default width to get the left edge.
    chrome.test.assertEq(
        255 - DEFAULT_TEXTBOX_WIDTH / 2,
        initEvent.detail.annotation.textBoxRect.locationX);
    // The visible page starts at the y shadow/margin, which is 6, and goes to
    // the viewport edge. The center is (500 + 6) / 2 = 253. Subtract half the
    // default height to get the top edge.
    chrome.test.assertEq(
        253 - MIN_TEXTBOX_SIZE_PX / 2,
        initEvent.detail.annotation.textBoxRect.locationY);
    chrome.test.assertEq(
        DEFAULT_TEXTBOX_WIDTH, initEvent.detail.annotation.textBoxRect.width);
    chrome.test.assertEq(0, initEvent.detail.annotation.pageIndex);
    chrome.test.assertEq(10, initEvent.detail.pageDimensions.x);
    chrome.test.assertEq(6, initEvent.detail.pageDimensions.y);
    chrome.test.assertEq(780, initEvent.detail.pageDimensions.width);
    chrome.test.assertEq(980, initEvent.detail.pageDimensions.height);

    // Zoom to 0.5. The new box should still be centered on the page, even
    // though it is not centered in the viewport.
    viewport.setZoom(0.5);
    // Initialize without a location. This is what happens when the user creates
    // a textbox by using "Enter" on the plugin, instead of with the mouse.
    initEvent = await changeActiveAnnotation(manager, null);

    chrome.test.assertEq(
        MIN_TEXTBOX_SIZE_PX, initEvent.detail.annotation.textBoxRect.height);

    // The default width goes down from 222 to the width of the page, which is
    // 195 at 0.5 zoom ( 400 * 0.5 - 2 * shadow ).
    // The page is centered on the viewport in the x direction, so it runs from
    // 152.5 to 347.5. The center is at (152.5 + 347.5) / 2 = 250. Subtract half
    // the default width to get the left edge.
    chrome.test.assertEq(
        250 - 195 / 2, initEvent.detail.annotation.textBoxRect.locationX);
    // The page starts at the y margin/shadow of 1.5 and runs to 246.5 since it
    // is 245 tall without the shadows. The center is at
    // (1.5 + 246.5) / 2 = 124. Subtract half the default height to get the top
    // edge.
    chrome.test.assertEq(
        124 - MIN_TEXTBOX_SIZE_PX / 2,
        initEvent.detail.annotation.textBoxRect.locationY);
    chrome.test.assertEq(195, initEvent.detail.annotation.textBoxRect.width);
    chrome.test.assertEq(0, initEvent.detail.annotation.pageIndex);
    chrome.test.assertEq(152.5, initEvent.detail.pageDimensions.x);
    chrome.test.assertEq(1.5, initEvent.detail.pageDimensions.y);
    chrome.test.assertEq(195, initEvent.detail.pageDimensions.width);
    chrome.test.assertEq(245, initEvent.detail.pageDimensions.height);

    chrome.test.succeed();
  },

  async function testInitializeTextboxClampToPage() {
    const manager = await setUpTextMode();
    const whenInitEvent = eventToPromise<CustomEvent<TextBoxInit>>(
        'initialize-text-box', manager);

    // Test initializing with the top left corner of the box near the right edge
    // of the page. Instead of initializing at this point, this should
    // initialize within the page boundaries.
    const created1 = await manager.initializeTextAnnotation({x: 425, y: 400});
    chrome.test.assertTrue(created1);
    let initEvent = await whenInitEvent;

    chrome.test.assertEq(
        MIN_TEXTBOX_SIZE_PX, initEvent.detail.annotation.textBoxRect.height);
    // Offset the box from the page edge by the width of the box. The box gets a
    // width of 2x the minimum allowed by Blink.
    chrome.test.assertEq(
        445 - 2 * MIN_TEXTBOX_SIZE_PX,
        initEvent.detail.annotation.textBoxRect.locationX);
    // y needs no adjustment in this case, since the location is far enough
    // from the bottom boundary of the page. y is always offset by half the
    // text height.
    chrome.test.assertEq(
        400 - manager.getCurrentTextAttributes().size / 2,
        initEvent.detail.annotation.textBoxRect.locationY);
    chrome.test.assertEq(
        2 * MIN_TEXTBOX_SIZE_PX, initEvent.detail.annotation.textBoxRect.width);

    // Now test initializing very close to the bottom of the page. This should
    // instead initialize far enough from bottom to fit the box.
    initEvent = await changeActiveAnnotation(manager, {x: 200, y: 490});

    chrome.test.assertEq(
        MIN_TEXTBOX_SIZE_PX, initEvent.detail.annotation.textBoxRect.height);
    chrome.test.assertEq(
        200, initEvent.detail.annotation.textBoxRect.locationX);
    chrome.test.assertEq(
        493 - MIN_TEXTBOX_SIZE_PX,
        initEvent.detail.annotation.textBoxRect.locationY);
    chrome.test.assertEq(
        DEFAULT_TEXTBOX_WIDTH, initEvent.detail.annotation.textBoxRect.width);

    chrome.test.succeed();
  },

  async function testInitializeTextBox() {
    const manager = await setUpTextMode();
    // Add listeners for the expected events that fire in response to an
    // initializeTextAnnotation call. Only attributes-changed events need to be
    // collected here, as initialize-text-box is handled by the helper.
    let attributesChangedEvents: Array<CustomEvent<TextAttributes>> = [];
    manager.addEventListener('attributes-changed', e => {
      attributesChangedEvents.push(e as CustomEvent<TextAttributes>);
    });

    const attributes = manager.getCurrentTextAttributes();
    async function verifyTextboxInit(
        x: number, y: number, rotation: number, id: number) {
      const initEvent = await changeActiveAnnotation(manager, {x, y});

      const initData = initEvent.detail;
      chrome.test.assertEq('', initData.annotation.text);
      assertDeepEquals(attributes, initData.annotation.textAttributes);
      chrome.test.assertEq(
          MIN_TEXTBOX_SIZE_PX, initData.annotation.textBoxRect.height);
      chrome.test.assertEq(x, initData.annotation.textBoxRect.locationX);
      chrome.test.assertEq(
          y - manager.getCurrentTextAttributes().size / 2,
          initData.annotation.textBoxRect.locationY);
      chrome.test.assertEq(
          DEFAULT_TEXTBOX_WIDTH, initData.annotation.textBoxRect.width);
      chrome.test.assertEq(0, initData.annotation.pageIndex);
      chrome.test.assertEq(id, initData.annotation.id);
      chrome.test.assertEq(rotation, initData.annotation.textOrientation);
      // Placeholder viewport has a 400x500 page and 500x500 window.
      // The y offset is always 3px, because the page is always positioned
      // 3px from the top. When the page is oriented vertically, it is centered
      // in the viewport with an additional 5px margin in x, creating pageX =
      // (500 - 400)/2 + 5 = 55px offset. When the page is oriented
      // horizontally, it is as wide as the viewport, so it uses the minimum
      // 5px margin for pageX.
      chrome.test.assertEq(
          rotation % 2 === 0 ? 55 : 5, initData.pageDimensions.x);
      chrome.test.assertEq(3, initData.pageDimensions.y);

      chrome.test.assertEq(1, attributesChangedEvents.length);
      assertDeepEquals(attributes, attributesChangedEvents[0]!.detail);
      attributesChangedEvents = [];

      // Since this is a new annotation, it shouldn't have sent a message to the
      // plugin.
      verifyEditTextAnnotationMessage(false);
    }

    // Test initialization in different positions and different viewport
    // rotations. id should increment with each new textbox.
    rotateViewport(/* clockwiseRotations= */ 3);
    await verifyTextboxInit(/* x= */ 15, /* y= */ 10, /* rotations= */ 1,
                            /* id= */ 0);
    rotateViewport(/* clockwiseRotations= */ 2);
    await verifyTextboxInit(/* x= */ 60, /* y= */ 60, /* rotations= */ 2,
                            /* id= */ 1);
    rotateViewport(/* clockwiseRotations= */ 1);
    await verifyTextboxInit(/* x= */ 80, /* y = */ 20, /* rotations= */ 3,
                            /* id= */ 2);
    rotateViewport(/* clockwiseRotations= */ 0);
    await verifyTextboxInit(/* x= */ 200, /* y= */ 23, /* rotations= */ 0,
                            /* id= */ 3);

    chrome.test.succeed();
  },

  async function testCommitTextAnnotation() {
    const manager = setUpInk2Manager();
    async function testCommitAnnotation(
        annotationScreenCoords: TextAnnotation,
        annotationPageCoords: TextAnnotationMessageData) {
      // Committing with edited = true should fire a modified event.
      // Use structuredClone since the manager edits the object in place,
      // and the object must be reused below.
      annotationPageCoords.isEdited = true;
      const editedAnnot = structuredClone(annotationScreenCoords);
      let whenUpdated = eventToPromise('annotations-updated', manager);
      manager.commitTextAnnotation(editedAnnot, true, []);
      verifyFinishTextAnnotationMessage(annotationPageCoords);
      await whenUpdated;
      mockPlugin.clearMessages();

      // Committing with edited = false should fire an unmodified event.
      annotationPageCoords.isEdited = false;
      const uneditedAnnot = structuredClone(annotationScreenCoords);
      whenUpdated = eventToPromise('annotations-updated', manager);
      manager.commitTextAnnotation(uneditedAnnot, false, []);
      verifyFinishTextAnnotationMessage(annotationPageCoords);
      await whenUpdated;
      mockPlugin.clearMessages();
    }

    // Test committing annotations at different rotations to ensure the
    // conversion back to page coordinates works correctly. Note that the
    // page screen rectangle will be 390x490 since there are 10px of page
    // shadow.

    // 90 degrees CCW
    rotateViewport(/* clockwiseRotations= */ 3);
    let annotationScreenCoords: TextAnnotation = getTestAnnotation(3);
    let annotationPageCoords: TextAnnotationMessageData =
        getTestAnnotationMessageData(3);
    annotationPageCoords.textBoxRect = {
      height: 50,
      width: 35,
      locationX: 333,
      locationY: 55,
    };
    await testCommitAnnotation(annotationScreenCoords, annotationPageCoords);
    // Delete to clear state.
    annotationScreenCoords.text = '';
    manager.commitTextAnnotation(annotationScreenCoords, true, []);
    mockPlugin.clearMessages();

    // 180 degrees
    rotateViewport(/* clockwiseRotations= */ 2);
    annotationScreenCoords = getTestAnnotation(2);
    annotationPageCoords = getTestAnnotationMessageData(2);
    // Adjust by the x and y offsets to get to page coordinates.
    annotationPageCoords.textBoxRect = {
      height: 35,
      width: 50,
      locationX: 335,
      locationY: 433,
    };
    await testCommitAnnotation(annotationScreenCoords, annotationPageCoords);
    // Delete to clear state.
    annotationScreenCoords.text = '';
    manager.commitTextAnnotation(annotationScreenCoords, true, []);
    mockPlugin.clearMessages();

    // 90 degrees CW
    rotateViewport(/* clockwiseRotations= */ 1);
    annotationScreenCoords = getTestAnnotation(1);
    annotationPageCoords = getTestAnnotationMessageData(1);
    // Adjust by the x and y offsets to get to page coordinates.
    annotationPageCoords.textBoxRect = {
      height: 50,
      width: 35,
      locationX: 22,
      locationY: 385,
    };
    await testCommitAnnotation(annotationScreenCoords, annotationPageCoords);
    // Delete to clear state.
    annotationScreenCoords.text = '';
    manager.commitTextAnnotation(annotationScreenCoords, true, []);
    mockPlugin.clearMessages();

    // Normal orientation (0 degrees).
    rotateViewport(/* clockwiseRotations= */ 0);
    annotationScreenCoords = getTestAnnotation(0);
    annotationPageCoords = getTestAnnotationMessageData(0);
    // Adjust by the x and y offsets to get to page coordinates.
    annotationPageCoords.textBoxRect = {
      height: 35,
      width: 50,
      locationX: 5,
      locationY: 22,
    };
    await testCommitAnnotation(annotationScreenCoords, annotationPageCoords);
    chrome.test.succeed();
  },


  function testFontCaching() {
    const manager = setUpInk2Manager();
    assertDeepEquals([], manager.getKnownFontIds());

    manager.addKnownFontId(1);
    assertDeepEquals([1], manager.getKnownFontIds());
    manager.addKnownFontId(2);
    assertDeepEquals([1, 2], manager.getKnownFontIds());

    // verify that getKnownFontIds() returns a copy.
    const ids = manager.getKnownFontIds();
    ids.push(3);
    assertDeepEquals([1, 2], manager.getKnownFontIds());

    chrome.test.succeed();
  },

  function testUndoRedoStack() {
    const manager = setUpInk2Manager();

    let lastState: UndoRedoStateChangedDetail|null = null;
    manager.addEventListener('undo-redo-state-changed', (e: Event) => {
      lastState = (e as CustomEvent<UndoRedoStateChangedDetail>).detail;
    });

    // Helper to assert stack state
    function assertStackState(
        canUndo: boolean, canRedo: boolean, hasUnsavedEdits: boolean) {
      assert(lastState);
      chrome.test.assertEq(canUndo, lastState.canUndo);
      chrome.test.assertEq(canRedo, lastState.canRedo);
      chrome.test.assertEq(hasUnsavedEdits, lastState.hasUnsavedEdits);
    }

    // 1. Finish ink stroke adds to the stack
    PluginController.getInstance().getEventTarget().dispatchEvent(
        new CustomEvent(
            PluginControllerEventType.FINISH_INK_STROKE, {detail: true}));
    assertStackState(true, false, true);

    // 2. Commit text annotation (edited) - adds to the stack
    const testAnnotation = getTestAnnotation(0);
    manager.commitTextAnnotation(testAnnotation, true, []);
    assertStackState(true, false, true);

    // 3. Commit a text annotation with no edits. This should not impact
    //    the undo/redo stack or fire an event.
    lastState = null;
    const testAnnotation2 = getTestAnnotation(1);
    manager.commitTextAnnotation(testAnnotation2, false, []);
    // Since it wasn't edited, no 'undo-redo-state-changed' event should have
    // fired.
    chrome.test.assertTrue(lastState === null);

    // 4. Finish ink stroke adds to the stack
    PluginController.getInstance().getEventTarget().dispatchEvent(
        new CustomEvent(
            PluginControllerEventType.FINISH_INK_STROKE, {detail: true}));
    // Stack now has: [Ink, Text, Ink]
    assertStackState(true, false, true);

    // 5. Undo
    manager.undo();
    assertStackState(true, true, true);  // Pointer moved back, can redo now

    // 6. Undo again
    manager.undo();
    assertStackState(true, true, true);

    // 7. Undo again (back to start)
    manager.undo();
    // No unsaved edits, and can't undo any more.
    assertStackState(false, true, false);

    // 8. Redo
    manager.redo();
    assertStackState(true, true, true);  // Can undo and redo

    // 9. Save
    manager.initiateSave();
    manager.saved();
    assertStackState(true, true, false);  // No unsaved edits anymore

    // 10. Push new action after save
    PluginController.getInstance().getEventTarget().dispatchEvent(
        new CustomEvent(
            PluginControllerEventType.FINISH_INK_STROKE, {detail: true}));
    // Can't redo any more, because the previous action/annotation has been
    // removed. Stack is dirty again due to the new action.
    assertStackState(true, false, true);

    // 11. Undo to the last save
    manager.undo();                       // Undo the new action
    assertStackState(true, true, false);  // Back to saved state, not dirty.

    // 12. Undo past the last save.
    manager.undo();
    // Dirty again (saved action was removed).
    assertStackState(false, true, true);

    // 13. Redo back to save
    manager.redo();
    assertStackState(true, true, false);  // Clean again

    chrome.test.succeed();
  },

  async function testUndoRedoTextAnnotationContent() {
    const manager = await setUpTextMode();
    // Helper to check if annotation exists in manager
    function assertAnnotationExists(
        id: number, exists: boolean, expectedText?: string) {
      const pageAnnots = manager.annotations.get(0);
      if (exists) {
        chrome.test.assertTrue(pageAnnots !== undefined);
        const annot = pageAnnots.get(id);
        chrome.test.assertTrue(annot !== undefined);
        if (expectedText !== undefined) {
          chrome.test.assertEq(expectedText, annot.text);
        }
      } else if (pageAnnots) {
        chrome.test.assertTrue(pageAnnots.get(id) === undefined);
      }
    }

    // Initialize new annotation (id 0)
    const whenInitEvent = eventToPromise<CustomEvent<TextBoxInit>>(
        'initialize-text-box', manager);
    const created1 = await manager.initializeTextAnnotation({x: 100, y: 100});
    chrome.test.assertTrue(created1);
    const initEvent = await whenInitEvent;
    const annotation0Screen = initEvent.detail.annotation;
    chrome.test.assertEq(0, annotation0Screen.id);

    // Save a copy of screen coords for future steps.
    const annotation0ScreenCoords = structuredClone(annotation0Screen);

    // Prepare page coords object for commit.
    const annotation0Page = structuredClone(annotation0Screen);
    annotation0Page.text = 'Hello';

    // Set up expectation with values shared by all checks.
    const expectedMessage = getTestAnnotationMessageData(0);
    expectedMessage.textBoxRect.width = 222;
    expectedMessage.textBoxRect.height = 24;
    expectedMessage.textBoxRect.locationX = 45;
    expectedMessage.textBoxRect.locationY = 91;
    expectedMessage.isEdited = true;

    // Commit creation (converts annotation0Page to page coords in-place)
    let whenUpdated = eventToPromise('annotations-updated', manager);
    manager.commitTextAnnotation(annotation0Page, true, []);
    // New message is from the user.
    expectedMessage.text = 'Hello';
    expectedMessage.source = TextAnnotationSource.USER;
    verifyFinishTextAnnotationMessage(expectedMessage);
    assertAnnotationExists(0, true, 'Hello');
    await whenUpdated;
    mockPlugin.clearMessages();

    // Undo creation -> should delete it
    whenUpdated = eventToPromise('annotations-updated', manager);
    manager.undo();
    assertAnnotationExists(0, false);
    // Deletion sends a message to the plugin with empty text
    expectedMessage.text = '';
    expectedMessage.source = TextAnnotationSource.UNDO;
    verifyFinishTextAnnotationMessage(expectedMessage);
    await whenUpdated;
    mockPlugin.clearMessages();

    // Redo creation -> should restore it
    whenUpdated = eventToPromise('annotations-updated', manager);
    manager.redo();
    assertAnnotationExists(0, true, 'Hello');
    expectedMessage.text = 'Hello';
    expectedMessage.source = TextAnnotationSource.REDO;
    verifyFinishTextAnnotationMessage(expectedMessage);
    await whenUpdated;
    mockPlugin.clearMessages();

    // Reactivate the existing annotation (id 0) for edit.
    // Note: reactivateTextAnnotation expects an annotation with its
    // rectangle in page coordinates.
    manager.reactivateTextAnnotation(annotation0Page);
    verifyEditTextAnnotationMessage(true, 0);

    const annotation0EditScreen = {
      ...annotation0ScreenCoords,
      text: 'World',
    };

    // Commit modification. Note that commitTextAnnotation will
    // convert the coordinates in place, so make a clone to hold the
    // page coordinate version.
    const annotation0EditPage = structuredClone(annotation0EditScreen);
    whenUpdated = eventToPromise('annotations-updated', manager);
    manager.commitTextAnnotation(annotation0EditPage, true, []);
    await whenUpdated;
    expectedMessage.text = 'World';
    expectedMessage.source = TextAnnotationSource.USER;
    verifyFinishTextAnnotationMessage(expectedMessage);
    assertAnnotationExists(0, true, 'World');
    mockPlugin.clearMessages();

    // Undo modification -> should restore to 'Hello'
    whenUpdated = eventToPromise('annotations-updated', manager);
    manager.undo();
    await whenUpdated;
    assertAnnotationExists(0, true, 'Hello');
    expectedMessage.text = 'Hello';
    expectedMessage.source = TextAnnotationSource.UNDO;
    verifyFinishTextAnnotationMessage(expectedMessage);
    mockPlugin.clearMessages();

    // Redo modification -> should change back to 'World'
    whenUpdated = eventToPromise('annotations-updated', manager);
    manager.redo();
    await whenUpdated;
    assertAnnotationExists(0, true, 'World');
    expectedMessage.text = 'World';
    expectedMessage.source = TextAnnotationSource.REDO;
    verifyFinishTextAnnotationMessage(expectedMessage);
    mockPlugin.clearMessages();

    // Reactivate existing annotation (id 0) for edit.
    manager.reactivateTextAnnotation(annotation0EditPage);
    verifyEditTextAnnotationMessage(true, 0);

    const annotation0DeleteScreen = {
      ...annotation0ScreenCoords,
      text: '',
    };
    const annotation0DeletePage = structuredClone(annotation0DeleteScreen);

    // Commit deletion (converts annotation0DeletePage in-place)
    whenUpdated = eventToPromise('annotations-updated', manager);
    manager.commitTextAnnotation(annotation0DeletePage, true, []);
    await whenUpdated;
    expectedMessage.text = '';
    expectedMessage.source = TextAnnotationSource.USER;
    verifyFinishTextAnnotationMessage(expectedMessage);
    assertAnnotationExists(0, false);
    mockPlugin.clearMessages();

    // Undo deletion -> should restore to 'World'
    whenUpdated = eventToPromise('annotations-updated', manager);
    manager.undo();
    await whenUpdated;
    assertAnnotationExists(0, true, 'World');
    expectedMessage.text = 'World';
    expectedMessage.source = TextAnnotationSource.UNDO;
    verifyFinishTextAnnotationMessage(expectedMessage);
    mockPlugin.clearMessages();

    // Redo deletion -> should delete again
    whenUpdated = eventToPromise('annotations-updated', manager);
    manager.redo();
    await whenUpdated;
    assertAnnotationExists(0, false);
    expectedMessage.text = '';
    expectedMessage.source = TextAnnotationSource.REDO;
    verifyFinishTextAnnotationMessage(expectedMessage);
    mockPlugin.clearMessages();

    chrome.test.succeed();
  },

  async function testUndoRedoWithZoomChange() {
    const manager = await setUpTextMode();
    // Draw a text box (id 0) at zoom 1.0
    const initEvent = await changeActiveAnnotation(manager, {x: 100, y: 100});
    const annot = initEvent.detail.annotation;
    annot.text = 'Zoom';

    // Set up expectation with values shared by all checks.
    const expectedMessage = getTestAnnotationMessageData(0);
    expectedMessage.textBoxRect.width = 222;
    expectedMessage.textBoxRect.height = 24;
    expectedMessage.textBoxRect.locationX = 45;
    expectedMessage.textBoxRect.locationY = 91;
    expectedMessage.isEdited = true;

    // Commit creation
    manager.commitTextAnnotation(annot, true, []);
    expectedMessage.text = 'Zoom';
    expectedMessage.source = TextAnnotationSource.USER;
    verifyFinishTextAnnotationMessage(expectedMessage);
    mockPlugin.clearMessages();

    // Undo
    manager.undo();
    expectedMessage.text = '';
    expectedMessage.source = TextAnnotationSource.UNDO;
    verifyFinishTextAnnotationMessage(expectedMessage);
    mockPlugin.clearMessages();

    // Zoom to 2.0 and redo.
    viewport.setZoom(2.0);
    manager.redo();
    expectedMessage.text = 'Zoom';
    expectedMessage.source = TextAnnotationSource.REDO;
    verifyFinishTextAnnotationMessage(expectedMessage);

    chrome.test.succeed();
  },

  async function testCommitViewportRotationTracking() {
    const manager = await setUpTextMode();
    mockPlugin.clearMessages();

    // Set viewport rotation to 270 degrees CW.
    rotateViewport(3);

    // Create a new text annotation.
    const whenInitEvent = eventToPromise<CustomEvent<TextBoxInit>>(
        'initialize-text-box', manager);
    chrome.test.assertTrue(
        await manager.initializeTextAnnotation({x: 100, y: 100}));
    const initEvent = await whenInitEvent;
    const annot = initEvent.detail.annotation;

    // Verify the text annotation correctly captures the viewport rotations on
    // commit.
    chrome.test.assertEq(3, annot.viewportOrientation);

    // Commit the annotation.
    annot.text = 'Hello';
    manager.commitTextAnnotation(annot, true, []);

    // Verify that the finishTextAnnotation message correctly captures the
    // viewport rotations on commit.
    const finishMsg =
        mockPlugin.findMessage<{type: string, data: TextAnnotationMessageData}>(
            'finishTextAnnotation');
    chrome.test.assertTrue(finishMsg !== undefined);
    chrome.test.assertEq(3, finishMsg.data.viewportOrientation);
    mockPlugin.clearMessages();

    // Rotate the viewport to 0 degrees.
    rotateViewport(0);

    // Undo.
    manager.undo();
    const undoMsg =
        mockPlugin.findMessage<{type: string, data: TextAnnotationMessageData}>(
            'finishTextAnnotation');
    chrome.test.assertTrue(undoMsg !== undefined);

    // Undo should still maintain commit viewport rotations.
    chrome.test.assertEq(3, undoMsg.data.viewportOrientation);
    mockPlugin.clearMessages();

    // Redo.
    manager.redo();
    const redoMsg =
        mockPlugin.findMessage<{type: string, data: TextAnnotationMessageData}>(
            'finishTextAnnotation');
    chrome.test.assertTrue(redoMsg !== undefined);

    // Redo should still maintain commit viewport rotations.
    chrome.test.assertEq(3, redoMsg.data.viewportOrientation);

    mockPlugin.clearMessages();
    chrome.test.succeed();
  },
]);
